

It consists of the following files:

  readme.txt         this file

  llncs.cls          the LaTeX2e document class for llncs template
 
  main.tex           the sample LaTeX2e file

  main.pdf	     the pdf document obtained with main.tex

  splncs03.bst       current LNCS BibTeX style with alphabetic sorting

  bibM2.bib	     the sample BibTeX file used in main.tex


 	     
  Makefile           the command « $make » compiles main.tex file with pdflatex and bibtex to obtain main.pdf
		     
